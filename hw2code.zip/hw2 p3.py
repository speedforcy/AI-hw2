#!/usr/bin/env python
# coding: utf-8

# In[45]:


from typing import Tuple, List
import random
import numpy as np
import numpy.typing as npt
import matplotlib.pyplot as plt
from random import sample

"""
Sudoku board initializer
Credit: https://stackoverflow.com/questions/45471152/how-to-create-a-sudoku-puzzle-in-python
"""
def generate(n: int, num_clues: int) -> dict:
    # Generate a sudoku problem of order n with "num_clues" cells assigned
    # Return dictionary containing clue cell indices and corresponding values
    # (You do not need to worry about components inside returned dictionary)
    N = range(n)

    rows = [g * n + r for g in sample(N, n) for r in sample(N, n)]
    cols = [g * n + c for g in sample(N, n) for c in sample(N, n)]
    nums = sample(range(1, n**2 + 1), n**2)

    S = np.array(
        [[nums[(n * (r % n) + r // n + c) % (n**2)] for c in cols] for r in rows]
    )
    indices = sample(range(n**4), num_clues)
    values = S.flatten()[indices]

    mask = np.full((n**2, n**4), True)
    mask[:, indices] = False
    i, j = np.unravel_index(indices, (n**2, n**2))

    for c in range(num_clues):
        v = values[c] - 1
        maskv = np.full((n**2, n**2), True)
        maskv[i[c]] = False
        maskv[:, j[c]] = False
        maskv[
            (i[c] // n) * n : (i[c] // n) * n + n, (j[c] // n) * n : (j[c] // n) * n + n
        ] = False
        mask[v] = mask[v] * maskv.flatten()

    return {"n": n, "indices": indices, "values": values, "valid_indices": mask}


def display(problem: dict):
    # Display the initial board with clues filled in (all other cells are 0)
    n = problem["n"]
    empty_board = np.zeros(n**4, dtype=int)
    empty_board[problem["indices"]] = problem["values"]
    print("Sudoku puzzle:\n", np.reshape(empty_board, (n**2, n**2)), "\n")


def initialize(problem: dict) -> npt.NDArray:
    # Returns a random initial sudoku board given problem
    n = problem["n"]
    S = np.zeros(n**4, dtype=int)
    S[problem["indices"]] = problem["values"]

    all_values = list(np.repeat(range(1, n**2 + 1), n**2))
    for v in problem["values"]:
        all_values.remove(v)
    all_values = np.array(all_values)
    np.random.shuffle(all_values)

    indices = [i for i in range(S.size) if i not in problem["indices"]]
    S[indices] = all_values
    S = S.reshape((n**2, n**2))

    return S


def successors(S: npt.NDArray, problem: dict) -> List[npt.NDArray]:
    # Returns list of all successor states of S by swapping two non-clue entries
    mask = problem["valid_indices"]
    indices = [i for i in range(S.size) if i not in problem["indices"]]
    succ = []

    for i in range(len(indices)):
        for j in range(i + 1, len(indices)):
            s = np.copy(S).flatten()
            if s[indices[i]] == s[indices[j]]:
                continue
            if not (
                mask[s[indices[i]] - 1, indices[j]]
                and mask[s[indices[j]] - 1, indices[i]]
            ):
                continue
            s[indices[i]], s[indices[j]] = s[indices[j]], s[indices[i]]
            succ.append(s.reshape(S.shape))

    return succ


"""
WRITE THIS FUNCTION
"""
def num_errors(S: npt.NDArray) -> int:
    
    # Given a current sudoku board state (2d NumPy array), compute and return total number of errors
    # Count total number of missing numbers from each row, column, and non-overlapping square blocks
    error = 0
    for l in S:
        size =len(l)
        for i in range(size):
            if i+1 not in l:
                error+=1
    for k in S.T:
        size =len(l)
        for i in range(size):
            if i+1 not in l:
                error+=1
    return error


"""
WRITE THIS FUNCTION
"""
def hill_climb(
    problem: dict,
    max_sideways: int = 0,
    max_restarts: int = 0
) -> Tuple[npt.NDArray, List[int]]:
    # Given: Sudoku problem and optional max sideways moves and max restarts parameters
    # Return: Board state solution (2d NumPy array), list of errors in each iteration of hill climbing search
    current = initialize(problem)
    errolist = []
    errors =[]
    side=0
    restarts=0
    while True:
        
        
        
        for i in successors(current,problem):
            errolist.append((num_errors(i),i))
            
        random.shuffle(errolist)
        neighbor = min(errolist, key = lambda t: t[0])
        best = [x for x in errolist if x[0]==neighbor[0]]
        
        errors.append(num_errors(current))
        
        
        if neighbor[0]>num_errors(current)and restarts <= max_restarts:
            restarts+=1
            current = initialize(problem)
            errolist = []
            errors =[]
            side=0
            
        elif neighbor[0]>num_errors(current)and restarts > max_restarts:
            return current,errors
        
        elif neighbor[0] == num_errors(current) and side <= max_sideways:
            current = random.choice(best)[1]
            side+=1
            
        elif side > max_sideways and restarts > max_restarts:
            return current,errors
        
        elif side > max_sideways and restarts <= max_restarts:
            restarts+=1
            current = initialize(problem)
            errolist = []
            errors =[]
            side=0

        else:
            current = neighbor[1]



# In[ ]:





# In[46]:


if __name__ == "__main__":
    n = 2
    clues = 5
    success =0
    final=0
    for i in range(100):
    
        problem = generate(n, clues)
        display(problem)
        sol, errors = hill_climb(problem,10,10)
        print("Solution:\n", sol)
        plt.figure()
        plt.plot(errors)
        plt.savefig(str(i))
        if min(errors)==0:
            success+=1
        else:
            final+=errors[-1]
            
            
    print(success)
    print(final/100)


# In[47]:





# In[48]:


if __name__ == "__main__":
    n = 3
    clues = 40
    success =0
    final=0
    while True:
    
        problem = generate(n, clues)
        display(problem)
        sol, errors = hill_climb(problem,10,20)
        print("Solution:\n", sol)
        plt.figure()
        
        if min(errors)==0:
            plt.plot(errors)
            plt.savefig('n=3 success2')
            break


# In[90]:





# In[ ]:




